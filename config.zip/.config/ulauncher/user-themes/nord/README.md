# ulauncher-nord
A nord theme for Ulauncher

### Screenshot

![A preview of the launcher](Screenshot_ulauncher.jpg)

### Installing
To install this theme, clone this repo to `~/.config/ulauncher/user-themes`
```
git clone https://github.com/KiranWells/ulauncher-nord/ \
  ~/.config/ulauncher/user-themes/nord
```
